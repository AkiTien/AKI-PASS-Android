# AKI PASS Android project

A minimal Android WebView wrapper for https://akipass.blogspot.com/.

## Build APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `AKI_PASS_Android` folder.
4. Allow Gradle sync and install any requested SDK components.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK is generated at:
   `app/build/outputs/apk/debug/app-debug.apk`

Alternatively, from the project folder:
`gradle assembleDebug`

## Notes
- This is a WebView app; the Blogger website must be reachable online.
- File downloads are handed to Android's browser/download handler. Upload forms use Android's file picker.
- Links outside the AKI PASS Blogspot domain open in an external browser.
- Test login, download links, and any Blogger custom scripts on a real device before distribution.
- For Google Play distribution, create a signed release build and review current Play policies.
